<?php
include("include/connection.php");
$sql= mysqli_query($con,"INSERT INTO `tbl_test`(`test`) VALUES ('rrr')");	
?>